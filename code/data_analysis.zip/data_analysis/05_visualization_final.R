# load packages
library(ggpubr)
library(tidyverse)

# set up color for visualization
col_PUhuman <- '#87CEFA'
col_PNhuman <- '#1874CD'
col_AUhuman <- "#40E0D0"
col_ANhuman <- "#00868B"
col_PUchimp <- "#D15FEE"
col_PNchimp <- "#8B008B"
col_AUchimp <- "#9B30FF"
col_ANchimp <- "#5D478B"

# rearrange data for visualization
plot_human <- Following_trial_total %>%
  ungroup() %>%
  filter(Group %in% c("Dutch children", "Dutch adults")) %>%
  mutate(ps_number = trial - 1) %>%
  dplyr::select(ps_number, follow_prop, Group, exp) %>%
  rbind(
    agent_dutch_peirs[, c(3, 4, 11, 12)],
    agent_dutch_risk[, c(3, 4, 11, 12)],
    agent_dutch_peirsno[, c(3, 4, 11, 12)],
    agent_dutch_riskno[, c(3, 4, 11, 12)]
  ) %>%
  mutate(Group = case_when(
    Group == 'PU' ~ "PU", 
    Group == 'AU' ~ 'AU',
    Group == 'AN' ~ 'AN',
    Group == 'PN' ~ 'PN',
    Group == 'Dutch children' ~ "Human", 
    Group == 'Dutch adults' ~ "Human"
  )) %>%
  filter(ps_number < 7, exp < 11)

# rearrange data for visualization
plot_chimp <- Following_trial_total %>%
  ungroup() %>%
  filter(Group == 'Chimpanzees') %>%
  mutate(ps_number = trial - 1) %>%
  dplyr::select(ps_number, follow_prop, Group, exp) %>%
  rbind(
    agent_chimp_peirs[, c(3, 4, 11, 12)],
    agent_chimp_risk[, c(3, 4, 11, 12)],
    agent_chimp_peirsno[, c(3, 4, 11, 12)],
    agent_chimp_riskno[, c(3, 4, 11, 12)]
  ) %>%
  mutate(Group = case_when(
    Group == 'PU' ~ "PU", 
    Group == 'AU' ~ 'AU',
    Group == 'AN' ~ 'AN',
    Group == 'PN' ~ 'PN',
    Group == 'Chimpanzees' ~ "Chimpanzees", 
  )) %>%
  filter(ps_number < 7, exp < 11)

# visualization (follow-explore) ----
ggplot(plot_human, aes(x = as.factor(ps_number), y = follow_prop, color = Group, group = Group)) +
  stat_summary(fun = mean, geom = "point", position = pd, size = 2.5) +
  stat_summary(fun = mean, geom = "line", position = pd, linewidth = 0.8) +
  stat_summary(fun.data = mean_sd, geom = "errorbar", position = pd, width = 0.5) +
  facet_wrap(~exp) +
  scale_color_manual(values = c(col_ANhuman, col_AUhuman,"gray45", col_PNhuman, col_PUhuman)) +
  xlab("Number of Fruits Found") +
  ylab("Proportion of Avatar-following Movement") +
  theme_minimal() +
  theme(strip.text = element_text(size = 12, face = "bold"),
        axis.title.x = element_text(size = 13, face = "bold"),
        axis.title.y = element_text(size = 13, face = "bold"),
        axis.text.x = element_text(size = 12),
        axis.text.y = element_text(size = 12),
  )

ggplot(plot_chimp, aes(x = as.factor(ps_number), y = follow_prop, color = Group, group = Group)) +
  stat_summary(fun = mean, geom = "point", position = pd, size = 2.5) +
  stat_summary(fun = mean, geom = "line", position = pd, linewidth = 0.8) +
  stat_summary(fun.data = mean_sd, geom = "errorbar", position = pd, width = 0.5) +
  facet_wrap(~exp) +
  scale_color_manual(values = c(col_ANchimp, col_AUchimp,"gray45", col_PNchimp, col_PUchimp)) +
  xlab("Number of Fruits Found") +
  ylab("Proportion of Avatar-following Movement") +
  theme_minimal() +
  theme(strip.text = element_text(size = 12, face = "bold"),
        axis.title.x = element_text(size = 13, face = "bold"),
        axis.title.y = element_text(size = 13, face = "bold"),
        axis.text.x = element_text(size = 12),
        axis.text.y = element_text(size = 12),
  )

# distance between curves ----
frechet_by_exp_total %>%
  filter(exp < 11) %>%
  mutate(Player = case_when(
    Group == "Hunter-gatherer" ~ 'Human',
    Group == "Dutch" ~ 'Human',
    Group == "Chimpanzees" ~ 'Chimpanzees'
  )) %>%
  mutate(color_group = case_when(
    Player == "Human" & Model == "AN" ~ "Human_AN",
    Player == "Human" & Model == "AU" ~ "Human_AU",
    Player == "Human" & Model == "PN" ~ "Human_PN",
    Player == "Human" & Model == "PU" ~ "Human_PU",
    Player == "Chimpanzees" & Model == "AN" ~ "Chimp_AN",
    Player == "Chimpanzees" & Model == "AU" ~ "Chimp_AU",
    Player == "Chimpanzees" & Model == "PN" ~ "Chimp_PN",
    Player == "Chimpanzees" & Model == "PU" ~ "Chimp_PU",
    TRUE ~ "grey" # fallback
  )) %>%
  ggplot(aes(x = Player, y = frechet_distance)) +
  geom_violin(aes(fill = color_group),
              position = position_dodge(width = 0.9), alpha = 0.4, trim = FALSE, color = "black") +
  geom_pointrange(
    data = summary_stats,
    aes(x = Player, y = mean, ymin = mean - se, ymax = mean + se, group = Model),
    position = position_dodge(width = 0.9),
    color = "black",
    size = 0.3
  ) +
  scale_fill_manual(
    name = "Model Type",
    values = c(
      "Human_AN" = col_ANhuman,
      "Human_AU" = col_AUhuman,
      "Human_PN" = col_PNhuman,
      "Human_PU" = col_PUhuman,
      "Chimp_AN" = col_ANchimp,
      "Chimp_AU" = col_AUchimp,
      "Chimp_PN" = col_PNchimp,
      "Chimp_PU" = col_PUchimp
    )
  )  +
  ylab('Frechet Distance') +
  theme_classic()

# regression model ----
fruits_visit_all %>%
  filter(group == 'BaYakaChildren'|
           group == 'DutchChild'|
           group == 'DutchAdults') %>%
  #rbind(ABM_plot[ABM_plot$group == 'chimpanzees', c(3,5,12)]) %>%
  #rbind(fruits_visit_hg) %>%
  rbind(fruits_visit_dutch) %>%
  ungroup() %>%
  mutate(Player = case_when(
    group == 'AU' ~ "ABM_AU", 
    group == 'AN' ~ "ABM_AN", 
    group == 'PU' ~ "ABM_PU", 
    group == 'PN' ~ "ABM_PN",
    group == 'BaYakaChildren' ~ "Human", 
    group == 'DutchChild' ~ "Human", 
    group == 'DutchAdults' ~ "Human"
  )) %>%
  filter(exp < 11) %>%
  ggscatter(x = 'exp', y = 'visit_number',
            add = 'reg.line', 
            #conf.int = TRUE,
            point = FALSE,
            color = "Player") +
  stat_smooth(
    method = "glm", 
    method.args = list(family = "poisson"), 
    #se = TRUE, 
    aes(color = Player, fill = Player, alpha = Player)
  ) +
  stat_cor(aes(color = Player), label.x = 1, label.y = c(7.5,7.4,7.3,7.2,7.1)) +
  scale_fill_manual(values = c(col_ANhuman, col_AUhuman, col_PNhuman, col_PUhuman,"gray50")) +
  scale_color_manual(values = c(col_ANhuman, col_AUhuman, col_PNhuman, col_PUhuman,"gray50")) +
  scale_alpha_manual(values = c(0.4, 0.4, 0.4, 0.4, 0.1)) +
  scale_x_continuous(breaks = c(1,2,3,4,5,6,7,8,9,10)) +
  xlab("Number of Gameplay Session") +
  ylab("Number of Fruits Founds")

fruits_visit_all %>%
  filter(group == 'Chimpanzees') %>%
  #rbind(ABM_plot[ABM_plot$group == 'chimpanzees', c(3,5,12)]) %>%
  #rbind(fruits_visit_hg) %>%
  rbind(fruits_visit_chimp) %>%
  ungroup() %>%
  mutate(Player = case_when(
    group == 'AU' ~ "ABM_AU", 
    group == 'AN' ~ "ABM_AN", 
    group == 'PU' ~ "ABM_PU", 
    group == 'PN' ~ "ABM_PN",
    group == 'Chimpanzees' ~ "Chimpanzees", 
  )) %>%
  filter(exp < 11) %>%
  ggscatter(x = 'exp', y = 'visit_number',
            add = 'reg.line', 
            #conf.int = TRUE,
            point = FALSE,
            color = "Player") +
  stat_smooth(
    method = "glm", 
    method.args = list(family = "poisson"), 
    #se = TRUE, 
    aes(color = Player, fill = Player, alpha = Player)
  ) +
  stat_cor(aes(color = Player), label.x = 1, label.y = c(7,6.8,6.6,6.4,6.2)) +
  scale_fill_manual(values = c(col_ANchimp, col_AUchimp, col_PNchimp, col_PUchimp,"gray50")) +
  scale_color_manual(values = c(col_ANchimp, col_AUchimp, col_PNchimp, col_PUchimp,"gray50")) +
  scale_alpha_manual(values = c(0.4, 0.4, 0.4, 0.4, 0.1)) +
  scale_x_continuous(breaks = c(1,2,3,4,5,6,7,8,9,10)) +
  xlab("Number of Gameplay Session") +
  ylab("Number of Fruits Founds")

# distribution of regression model ----
beta_real %>%
  filter(group == 'DutchChild'|
           group == 'DutchAdults') %>%
  rbind(beta_model_dutch) %>%
  ungroup() %>%
  mutate(Player = case_when(
    group == 'AU' ~ "ABM_AU", 
    group == 'AN' ~ "ABM_AN", 
    group == 'PU' ~ "ABM_PU", 
    group == 'PN' ~ "ABM_PN",
    group == 'DutchChild' ~ "Human", 
    group == 'DutchAdults' ~ "Human"
  )) %>%
  filter(exp < 11) %>%
  ggdensity(x = 'estimate', y = 'density',
            add = 'median', group = 'Player',
            alpha= 0.2, fill = "white",
            size = 0.75,
            color = "Player") +
  #scale_fill_manual(values = c(col_ANhuman, col_AUhuman, col_PNhuman, col_PUhuman, "gray50")) +
  scale_color_manual(values = c(col_ANhuman, col_AUhuman, col_PNhuman, col_PUhuman,"gray50")) +
  xlab("Estimates") +
  ylab("Density")

beta_real %>%
  filter(group == 'Chimapanzees') %>%
  rbind(beta_model_chimp) %>%
  ungroup() %>%
  mutate(Player = case_when(
    group == 'AU' ~ "ABM_AU", 
    group == 'AN' ~ "ABM_AN", 
    group == 'PU' ~ "ABM_PU", 
    group == 'PN' ~ "ABM_PN",
    group == 'DutchChild' ~ "Human", 
    group == 'DutchAdults' ~ "Human"
  )) %>%
  filter(exp < 11) %>%
  ggdensity(x = 'estimate', y = '..density..',
            add = 'median', group = 'Player',
            alpha= 0.2, fill = "white",
            size = 0.75,
            color = "Player") +
  #scale_fill_manual(values = c(col_ANchimp, col_AUchimp, col_PNchimp, col_PUchimp, "gray50")) +
  scale_color_manual(values = c(col_ANchimp, col_AUchimp, col_PNchimp, col_PUchimp,"gray50")) +
  xlab("Estimates") +
  ylab("Density")

# foraging efficiency (time of fruit found) ----
plot_fruits_chimp <- fruit_time_total %>%
  distinct(exp, time_find, name, group, trial) %>%
  filter(group == 'Chimpanzees') %>%
  ungroup() %>%
  rbind(
    fruit_time_human_total
  ) %>%
  mutate(Group = case_when(
    group == 'PU' ~ "PU", 
    group == 'AU' ~ 'AU',
    group == 'AN' ~ 'AN',
    group == 'PN' ~ 'PN',
    group == 'Chimpanzees' ~ "Chimpanzees", 
  )) %>%
  filter(ps_number < 7, exp < 11)

plot_fruits_human <- fruit_time_total %>%
  distinct(exp, time_find, name, group, trial) %>%
  filter(group %in% c("Dutch children", "Dutch adults")) %>%
  ungroup() %>%
  rbind(
    fruit_time_human_total
  ) %>%
  mutate(Group = case_when(
    group == 'PU' ~ "PU", 
    group == 'AU' ~ 'AU',
    group == 'AN' ~ 'AN',
    group == 'PN' ~ 'PN',
    group == 'DutchChild' ~ "Human", 
    group == 'DutchAdults' ~ "Human"
  )) %>%
  filter(ps_number < 7, exp < 11)

ggplot(plot_fruits_chimp, aes(x = as.factor(exp), y = time_find, color = Group, group = Group)) +
    stat_summary(fun = mean, geom = "point", position = pd, size = 2.5) +
    stat_summary(fun = mean, geom = "line", position = pd, linewidth = 0.8) +
    stat_summary(fun.data = mean_sd, geom = "errorbar", position = pd, width = 0.5) +
    facet_wrap(~trial) +
    scale_color_manual(values = c(col_ANchimp, col_AUchimp,"gray45", col_PNchimp, col_PUchimp)) +
    xlab("Number of Fruits Found") +
    ylab("Proportion of Avatar-following Movement") +
    theme_minimal() +
    theme(strip.text = element_text(size = 12, face = "bold"),
          axis.title.x = element_text(size = 13, face = "bold"),
          axis.title.y = element_text(size = 13, face = "bold"),
          axis.text.x = element_text(size = 12),
          axis.text.y = element_text(size = 12),
    )

ggplot(plot_fruits_human, aes(x = as.factor(exp), y = time_find, color = Group, group = Group)) +
  stat_summary(fun = mean, geom = "point", position = pd, size = 2.5) +
  stat_summary(fun = mean, geom = "line", position = pd, linewidth = 0.8) +
  stat_summary(fun.data = mean_sd, geom = "errorbar", position = pd, width = 0.5) +
  facet_wrap(~trial) +
  scale_color_manual(values = c(col_ANhuman, col_AUhuman,"gray45", col_PNhuman, col_PUhuman)) +
  xlab("Number of Gameplay Session") +
  ylab("Time") +
  theme_minimal() +
  theme(strip.text = element_text(size = 12, face = "bold"),
        axis.title.x = element_text(size = 13, face = "bold"),
        axis.title.y = element_text(size = 13, face = "bold"),
        axis.text.x = element_text(size = 12),
        axis.text.y = element_text(size = 12),
  )

# differences between matrix ----
js_results %>%
  arrange(model) %>%
  ggbarplot(x = 'model', y = 'JSD', add = 'mean_se',
            fill = 'model', position = position_dodge(0.9)) +
  scale_fill_manual(name = 'Model', values = c(col_ANhuman, col_AUhuman, col_PNhuman, col_PUhuman)) +
  labs(title = "JS Divergence Between Transition Matrices",
       x = "Model",
       y = "Jensen–Shannon Divergence") +
  theme_minimal()

js_results %>%
  ggbarplot(x = 'tree_id', y = 'JSD',
            fill = 'model', position = position_dodge(0.9)) +
  scale_fill_manual(name = 'Model', values = c(col_ANhuman, col_AUhuman, col_PNhuman, col_PUhuman)) +
  labs(title = "JS Divergence Between Transition Matrices",
       x = "Tree ID",
       y = "Jensen–Shannon Divergence") +
  theme_minimal()

# sequence edit distance ----
model_summary <- seq_pairs_model %>%
  group_by(next_exp) %>%
  summarise(
    mean_dist = mean(distance, na.rm = TRUE),
    se_dist = sd(distance, na.rm = TRUE) / sqrt(n())
  ) %>%
  arrange(next_exp)

real_summary <- seq_pairs_real %>%
  filter(group == DutchAdults|
           group == DutchChildren) %>%
  group_by(next_exp) %>%
  summarise(
    mean_dist = mean(distance, na.rm = TRUE),
    se_dist = sd(distance, na.rm = TRUE) / sqrt(n())
  ) %>%
  arrange(next_exp)

ggplot() +
  # model data
  geom_line(data = model_summary,
            aes(x = next_exp + 1, y = mean_dist, color = Model),
  ) +
  geom_errorbar(data = model_summary,
                aes(x = next_exp + 1, ymin = mean_dist - se_dist, 
                    ymax = mean_dist + se_dist, color = Model),
  ) +
  
  # real data
  geom_line(data = real_summary,
            aes(x = next_exp + 1, y = mean_dist),
            color = "black", linetype = "dashed") +
  geom_errorbar(data = real_summary,
                aes(x = next_exp + 1, ymin = mean_dist - se_dist, ymax = mean_dist + se_dist),
                color = "black") +
  scale_color_manual(name = 'Model', values = c(col_ANhuman, col_AUhuman, col_PNhuman, col_PUhuman)) +
  scale_fill_manual(name = 'Model', values = c(col_ANhuman, col_AUhuman, col_PNhuman, col_PUhuman)) +
  facet_wrap(~Model) +
  labs(
    x = "Gameplay Session",
    y = "Levenshtein Distance",
    title = "Mean Edit Distance Across Sessions (Model vs. Human)"
  ) +
  scale_x_continuous(breaks = model_summary$next_exp + 1) +
  theme_minimal()
