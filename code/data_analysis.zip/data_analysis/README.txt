Repository Contents

This repository contains scripts for analyzing outputs from an agent-based model (ABM) investigating primate foraging decision-making.

01_extract_data
Extracts relevant variables from raw ABM outputs. Performs initial visualizations of follow–explore dynamics and foraging efficiency for use in subsequent analyses.

02_similarity_between_curve
Computes the Fréchet distance between follow–explore dynamics observed in empirical (real-world) data and simulated ABM outputs, enabling quantitative comparison of movement patterns.

03_glm_ABM
Fits generalized linear models to evaluate the relationship between the number of fruits located and the number of gameplay sessions in the ABM simulations.

04_spatial_learning
Constructs transition matrices from ABM data and performs analyses to quantify spatial learning and movement strategy changes over time.

05_visualization_final
Generates final visualizations summarizing results from all preceding analyses, including comparative plots and spatial behavior diagrams.

check_abm_output
Produces quick diagnostic visualizations of raw ABM outputs to verify data integrity before formal analysis.
