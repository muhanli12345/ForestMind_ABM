# load data
library(tidyverse)
library(ggpubr)

agent_memory_plot <- agent_memory %>% group_by(re, sim_seed) %>%
  mutate(fruit_find = max(ps_number)) %>%
  group_by(sim_seed, ps_number, re) %>%
  mutate(tree_move = max(n_choices_tree),
         avt_move = max(n_choices_knowledgeable),
         iteration = max(n_choices_total))%>%
  distinct(sim_seed, ps_number, fruit_find, tree_move, avt_move, iteration, re) %>%
  ungroup()

agent_memory_plot <- merge(agent_memory_plot, fruits_visited[,c(8,15,16,17)], by = c("re", "iteration"))

agent_track_plot <- fruits_visited %>% distinct(sim_seed, intrinsic_load, risk, re)

strategy_value_plot <- na.omit(strategy_memory)

agent_memory_plot %>%
  ggline(x = 'sim_seed', y = 'fruit_find',
         add = "mean_sd",
         color = "slateblue1") +
  xlab("Simulation Time") +
  ylab("Number of Fruits Founds")

agent_track_plot %>%
  ggline(x = 'sim_seed', y = 'intrinsic_load',
         add = "mean_sd",
         color = "slateblue1") +
  xlab("Number of Gameplay Session") +
  ylab("Uncertainty of Environment")

agent_memory_plot %>% filter(ps_number < 7) %>%
  ggline(x = 'ps_number', y = 'intrinsic_load',
         add = "mean_sd",
         color = "slateblue1") +
  xlab("Number of Fruits Founds") +
  ylab("Intrinsic Load")

agent_memory_plot %>%
  ggline(x = 'sim_seed', y = 'risk',
         add = "mean_se",
         color = "slateblue1") +
  xlab("Simulation Time") +
  ylab("Learned Risk")

strategy_value_plot %>%
  ggline(x = 'sim_seed', y = 'bayesian_prob_avatar',
         add = "mean_sd",
         color = "slateblue1") +
  xlab("Simulation Time") +
  ylab("avatar_choice_prob")

strategy_value_plot %>%
  ggline(x = 'sim_seed', y = 'bayesian_prob_random',
         add = "mean_sd",
         color = "slateblue1") +
  xlab("Simulation Time") +
  ylab("avatar_choice_prob")

strategy_value_plot %>%
  ggline(x = 'sim_seed', y = 'random_choice_prob',
         add = "mean_sd",
         color = "slateblue1") +
  xlab("Simulation Time") +
  ylab("target_choice_prob")

agent_memory_plot$prop_tree <- agent_memory_plot$tree_move/(agent_memory_plot$tree_move + agent_memory_plot$avt_move)
agent_memory_plot$prop_avt <- agent_memory_plot$avt_move/(agent_memory_plot$tree_move + agent_memory_plot$avt_move)

agent_memory_plot %>%
  filter(ps_number < 7) %>%
  ggline(x = 'ps_number', y = 'prop_avt',
         add = "mean_sd",
         color = "darkorange2") +
  xlab("Number of Fruits Founds") +
  ylab("Proportion of Avatar-target Move")

agent_memory_plot %>%
  ggline(x = 'sim_seed', y = 'prop_avt',
         add = "mean_sd",
         color = "darkorange2") +
  xlab("Simulation Time") +
  ylab("Proportion of Avatar-target Move")