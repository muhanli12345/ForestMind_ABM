# load packages
library(proxy)
library(SimilarityMeasures)
library(tidyverse)
library(ggpubr)

# rearrange the real-world data
curve_data <- Following_trial_total %>%
  mutate(ps_number = trial - 1)  %>%
  group_by(Group, exp, name, ps_number) %>%
  summarise(mean_follow = mean(follow_prop), .groups = "drop") %>%
  mutate(Group = case_when(
    Group == "Dutch children"|Group == "Dutch adults" ~ "Dutch",
    Group != "Dutch children" & Group != "Dutch adults" ~ Group
  ))
curve_data$type <- 'real'

# add the group column for ABM data
agent_dutch$Group <- "Dutch"
agent_hg$Group <- 'Hunter-gatherer'
agent_chimp$Group <- "Chimpanzees"

# rearrange the ABM data
agent_data <- bind_rows(agent_dutch, agent_hg, agent_chimp) %>%
  group_by(Group, exp, re, ps_number) %>%
  summarise(mean_follow = mean(follow_prop), .groups = "drop") %>%
  rename(name = re)
agent_data$name <- as.character(agent_data$name)
agent_data$type <- 'agent'

df_summary <- rbind(agent_data_riskno, curve_data)

# get all Group × exp combination
group_exp_combos <- df_summary %>%
  distinct(Group, exp)

all_matched_pairs <- list()

# match ABM data with real world data by mean_follow column
for (i in seq_len(nrow(group_exp_combos))) {
  group_val <- group_exp_combos$Group[i]
  exp_val   <- group_exp_combos$exp[i]
  
  # Extract the individual data
  sub_data <- df_summary %>%
    filter(Group == group_val, exp == exp_val)
  
  agents <- sub_data %>%
    filter(type == "agent") %>%
    rename(agent_id = name, mean_agent = mean_follow)
  
  reals <- sub_data %>%
    filter(type == "real") %>%
    rename(real_id = name, mean_real = mean_follow)
  
  # match the combination with a mean_follow difference < 0.05
  pairs <- merge(agents, reals, by = NULL) %>%
    filter(abs(mean_agent - mean_real) <= 0.05)
  
  if (nrow(pairs) > 0) {
    pairs$Group <- group_val
    pairs$exp <- exp_val
    all_matched_pairs[[length(all_matched_pairs) + 1]] <- pairs
  }
}

matched_pairs_df <- bind_rows(all_matched_pairs)
matched_pairs_df$frechet <- NA_real_

# calculate distance with individual
for (i in seq_len(nrow(matched_pairs_df))) {
  row <- matched_pairs_df[i, ]
  group_val <- row$Group
  exp_val <- row$exp
  aid <- row$agent_id
  rid <- row$real_id
  
  agent_curve <- df_summary %>%
    filter(Group == group_val, exp == exp_val, type == "agent", name == aid) %>%
    dplyr::select(ps_number, mean_follow) %>%
    drop_na() %>%
    as.matrix()
  
  real_curve <- df_summary %>%
    filter(Group == group_val, exp == exp_val, type == "real", name == rid) %>%
    dplyr::select(ps_number, mean_follow) %>%
    drop_na() %>%
    as.matrix()
  
  if (nrow(agent_curve) > 1 && nrow(real_curve) > 1) {
    matched_pairs_df$frechet[i] <- SimilarityMeasures::Frechet(agent_curve, real_curve)
  } else {
    matched_pairs_df$frechet[i] <- NA_real_
  }
}

matched_pairs_df <- matched_pairs_df %>% 
  distinct(agent_id, mean_agent, real_id, mean_real, Group, exp, frechet)

# general check first
ggboxplot(matched_pairs_df, x = "Group", y = "frechet")

# mean distance
frechet_by_exp <- df_summary %>%
  select(Group, exp, ps_number, type, mean_follow) %>%
  pivot_wider(names_from = type, values_from = mean_follow, values_fn = mean) %>%
  drop_na() %>%
  group_by(exp, Group) %>%
  summarise(
    frechet_distance = {
      # Format each curve as matrix: (x = n_fruit_found, y = mean_follow)
      agent_curve <- as.matrix(dplyr::select(cur_data(), ps_number, agent))
      human_curve <- as.matrix(dplyr::select(cur_data(), ps_number, real))
      SimilarityMeasures::Frechet(agent_curve, human_curve)
    },
    .groups = "drop"
  )

# general check first
ggboxplot(frechet_by_exp, x = "Group", y = "frechet_distance")

# repeat the above procedure to each model and then rearrange them into one dataframe
#frechet_by_exp_peirs <- frechet_by_exp
#frechet_by_exp_peirsno <- frechet_by_exp
#frechet_by_exp_risk <- frechet_by_exp
#frechet_by_exp_riskno <- frechet_by_exp
#frechet_by_exp_peirs$Model <- "PU"
#frechet_by_exp_risk$Model <- "AU"
#frechet_by_exp_peirsno$Model <- "PN"
#frechet_by_exp_riskno$Model <- "AN"
#frechet_by_exp_total <- rbind(frechet_by_exp_peirs, frechet_by_exp_risk, frechet_by_exp_peirsno, frechet_by_exp_riskno)

# calculate stats for results of four models for visualization
summary_stats <- frechet_by_exp_total %>%
  mutate(Player = case_when(
    Group == "Hunter-gatherer" ~ 'Human',
    Group == "Dutch" ~ 'Human',
    Group == "Chimpanzees" ~ 'Chimpanzees',
  )) %>%
  group_by(Player, Model) %>%
  summarise(
    mean = mean(frechet_distance, na.rm = TRUE),
    se = sd(frechet_distance, na.rm = TRUE) / sqrt(n()),
    .groups = 'drop'
  )

# final visualization of dataframe with results of four models
frechet_by_exp_total %>%
  filter(exp < 11) %>%
  mutate(Player = case_when(
    Group == "Hunter-gatherer" ~ 'Human',
    Group == "Dutch" ~ 'Human',
    Group == "Chimpanzees" ~ 'Chimpanzees'
  )) %>%
  mutate(color_group = case_when(
    Player == "Human" & Model == "AN" ~ "Human_AN",
    Player == "Human" & Model == "AU" ~ "Human_AU",
    Player == "Human" & Model == "PN" ~ "Human_PN",
    Player == "Human" & Model == "PU" ~ "Human_PU",
    Player == "Chimpanzees" & Model == "AN" ~ "Chimp_AN",
    Player == "Chimpanzees" & Model == "AU" ~ "Chimp_AU",
    Player == "Chimpanzees" & Model == "PN" ~ "Chimp_PN",
    Player == "Chimpanzees" & Model == "PU" ~ "Chimp_PU",
    TRUE ~ "grey" # fallback
  )) %>%
  ggplot(aes(x = Player, y = frechet_distance)) +
  geom_violin(aes(fill = color_group),
              position = position_dodge(width = 0.9), alpha = 0.4, trim = FALSE, color = "black") +
  geom_pointrange(
    data = summary_stats,
    aes(x = Player, y = mean, ymin = mean - se, ymax = mean + se, group = Model),
    position = position_dodge(width = 0.9),
    color = "black",
    size = 0.3
  ) +
  scale_fill_manual(
    name = "Model Type",
    values = c(
      "Human_AN" = "#87CEFA",
      "Human_AU" = "#1874CD",
      "Human_PN" = "#40E0D0",
      "Human_PU" = "#2F4F4F",
      "Chimp_AN" = "#D15FEE",
      "Chimp_AU" = "#8B008B",
      "Chimp_PN" = "#9B30FF",
      "Chimp_PU" = "#5D478B"
    )
  )  +
  ylab('Frechet Distance') +
  theme_classic()
