# load packages
library(ggpubr)
library(tidyverse)
library(dplyr)
library(purrr)
library(broom)
library(transport)

# load data (real-world data)
Following_trial_total <- read.csv("E:/ABM/ABM Files/data/real-world data/Following_trial_total.csv", row.names = 1)
fruits_visit_all <- read.csv("E:/ABM/ABM Files/data/real-world data/fruits_visit_all.csv", row.names = 1)
beta_real <- read.csv("E:/ABM/ABM Files/data/real-world data/beta_real.csv", row.names = 1)

# prepare the dataframe
agent_dutch_risk$Group <- 'AU'
agent_dutch_riskno$Group <- 'AN'
agent_dutch_peirs$Group <- 'PU'
agent_dutch_peirsno$Group <- 'PN'
agent_memory_plot$Group <- "PU"

# glm ----
model_AU <- glm(visit_number ~ exp, family = poisson(), data = agent_dutch_risk)
model_AN <- glm(visit_number ~ exp, family = poisson(), data = agent_dutch_riskno)
model_PU <- glm(visit_number ~ exp, family = poisson(), data = agent_dutch_peirs)
model_PN <- glm(visit_number ~ exp, family = poisson(), data = agent_dutch_peirsno)

# check the model output
summary(model_AU)
summary(model_AN)
summary(model_PU)
summary(model_PN)

# visualization
fruits_visit_dutch <- bind_rows(agent_dutch_peirs, agent_dutch_peirsno, agent_dutch_risk, agent_dutch_riskno) %>%
  select(exp, name = re, visit_number = fruit_find, group = Group)
fruits_visit_dutch$name <- as.character(fruits_visit_dutch$name)

fruits_visit_all %>%
  filter(#group == 'BaYakaChildren'|
           group == 'DutchChild'|
           group == 'DutchAdults') %>%
  rbind(fruits_visit_dutch) %>%
  ungroup() %>%
  mutate(Player = case_when(
    group == 'AU' ~ "ABM_AU", 
    group == 'AN' ~ "ABM_AN", 
    group == 'PU' ~ "ABM_PU", 
    group == 'PN' ~ "ABM_PN",
    group == 'DutchChild' ~ "Human", 
    group == 'DutchAdults' ~ "Human"
  )) %>%
  filter(exp < 11) %>%
  ggscatter(x = 'exp', y = 'visit_number',
         add = 'reg.line', 
         #conf.int = TRUE,
         point = FALSE,
         color = "Player") +
  stat_smooth(
    method = "glm", 
    method.args = list(family = "poisson"), 
    #se = TRUE, 
    alpha = 0.4,
    aes(color = Player, fill = Player)
  ) +
  stat_cor(aes(color = Player), label.x = 1, label.y = c(7.5,7.4,7.3,7.2,7.1)) +
  scale_fill_manual(values = c('#87CEFA', '#1874CD', "#40E0D0", "#00868B", "#00B2EE")) +
  scale_color_manual(values = c('#87CEFA', '#1874CD', "#40E0D0", "#00868B", "#00B2EE")) +
  scale_x_continuous(breaks = c(1,2,3,4,5,6,7,8,9,10)) +
  xlab("Number of Gameplay Session") +
  ylab("Number of Fruits Founds")

# glm for each individual  ----
beta_real <- fruits_visit_all %>%
  filter(group == 'BaYakaChildren'|
           group == 'DutchChild'|
           group == 'DutchAdults'|
           group == 'Chimpanzees') %>%
  group_by(name) %>%
  filter(exp < 11) %>%
  nest() %>%
  mutate(
    model = map(data, ~ glm(visit_number ~ exp, family = poisson,
                            data = .)),
    coef = map(model, tidy)
  ) %>%
  select(name, data, coef) %>%
  unnest(coef) %>%
  filter(term == 'exp') %>%
  select(name, data, estimate) %>%
  unnest(data) %>%
  distinct(name, group, estimate)

beta_model_dutch <- fruits_visit_dutch %>%
  group_by(name) %>%
  filter(exp < 11) %>%
  nest() %>%
  mutate(
    model = map(data, ~ glm(visit_number ~ exp, family = poisson,
                            data = .)),
    coef = map(model, tidy)
  ) %>%
  select(name, data, coef) %>%
  unnest(coef) %>%
  filter(term == 'exp') %>%
  select(name, data, estimate) %>%
  unnest(data) %>%
  distinct(name, group, estimate)

beta_real %>%
  filter(#group == 'BaYakaChildren'|
           group == 'DutchChild'|
           group == 'DutchAdults') %>%
  rbind(beta_model_dutch) %>%
  ungroup() %>%
  mutate(Player = case_when(
    group == 'AU' ~ "ABM_AU", 
    group == 'AN' ~ "ABM_AN", 
    group == 'PU' ~ "ABM_PU", 
    group == 'PN' ~ "ABM_PN",
    group == 'BaYakaChildren' ~ "Human", 
    group == 'DutchChild' ~ "Human", 
    group == 'DutchAdults' ~ "Human"
  )) %>%
  filter(exp < 11) %>%
  ggdensity(x = 'estimate', y = '..density..',
            add = 'median', group = 'Player',
            alpha=0.2, fill = "white",
            size = 0.75,
            color = "Player") +
  #scale_fill_manual(values = c('#87CEFA', '#1874CD', "#40E0D0", "#2F4F4F", "#00B2EE")) +
  scale_color_manual(values = c('#87CEFA', '#1874CD', "#40E0D0", "#2F4F4F", "#00B2EE")) +
  xlab("Estimates") +
  ylab("Density")

beta_compare <- beta_real %>%
  filter(group == 'DutchChild'|
      group == 'DutchAdults') %>%
  rbind(beta_model_dutch) %>%
  ungroup() %>%
  mutate(Player = case_when(
    group == 'AU' ~ "ABM_AU", 
    group == 'AN' ~ "ABM_AN", 
    group == 'PU' ~ "ABM_PU", 
    group == 'PN' ~ "ABM_PN",
    group == 'DutchChild' ~ "Human", 
    group == 'DutchAdults' ~ "Human"
  )) %>%
  select(-group)

# calculate the earth mover's distance for distributions ----
compute_emd <- function(human_vals, abm_vals) {
  if (length(human_vals) == 0 || length(abm_vals) == 0) return(NA)
  wasserstein1d(human_vals, abm_vals)
}

abm_groups <- c("ABM_PU", "ABM_PN", "ABM_AU", "ABM_AN")

emd_results <- beta_compare %>%
  drop_na() %>%
  filter(Player %in% c("Human", abm_groups)) %>%
  group_modify(~ {
    human_vals <- .x %>% filter(Player == "Human") %>% pull(estimate)
    
    tibble(
      Player = abm_groups,
      emd = purrr::map_dbl(abm_groups, function(abm) {
        abm_vals <- .x %>% filter(Player == abm) %>% pull(estimate)
        compute_emd(human_vals, abm_vals)
      })
    )
  }) %>%
  ungroup()

ggplot(emd_results, aes(x = Player, y = emd, fill = Player)) +
  geom_col(position = position_dodge(0.9), color = 'black') +
  labs(
    title = "Earth Mover’s Distance Between ABM and Human",
    x = "Model",
    y = "EMD"
  ) +
  scale_fill_manual(values = c('#87CEFA', '#1874CD', "#40E0D0", "#2F4F4F", "#00B2EE")) +
  theme_classic() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))