# load packages
library(dplyr)
library(tidyr)
library(stringdist)
library(purrr)
library(ggplot2)
library(scales)
library(geomtextpath)
library(ggpubr)
library(tidyverse)

# load real-world data
human_tp_matrix_wide <- read.csv("E:/ABM/ABM Files/data/real-world data/human_tp_matrix_wide.csv", row.names = 1) # transition matrix of dutch people

# ---- 1. identify the fruits found with following behaviour ----

# define the time window (delta_t)
delta_t_guided <- 10

# load and extract fruit info
# example: fruits_visited_PU <- read.csv("F:/ABM/fruits_visited_PU.csv")

fruit_find_PU <- fruits_visited_PU %>%
  mutate(
    visited_ids = str_split(as.character(trees_visited), ",") %>% 
      map(as.numeric)
  ) %>%
  group_by(sim_seed, re) %>%
  mutate(
    prev_fruit_trees = accumulate(visited_ids, 
                                  ~ unique(c(.x, .y[.y %in% fruit_trees$target_id])), 
                                  .init = list(numeric()))[-1],  
    prev_fruit_trees = ifelse(map_lgl(prev_fruit_trees, is_empty), NA, prev_fruit_trees),
    
    found_fruit = map2_lgl(visited_ids, lag(prev_fruit_trees, default = list(numeric())), 
                           ~ any(.x %in% fruit_trees$target_id & !.x %in% .y, na.rm = TRUE)) 
  ) %>%
  group_by(sim_seed, re) %>%
  mutate(cumulative_found = cumsum(found_fruit)) %>%
  filter(found_fruit)

# repeat to get data for all models
#fruit_find_AN$Model <- 'AN'
#fruit_find_AU$Model <- 'AU'
#fruit_find_PU$Model <- 'PU'
#fruit_find_PN$Model <- 'PN'

fruit_find_total <- rbind(fruit_find_AN, fruit_find_AU, fruit_find_PU, fruit_find_PN)

# add the column for fruit tree id
fruits_agent <- fruit_find_total %>%
  mutate(tree_id = case_when(
    (x < 30 & x > 10) & (y < 30 & y > 10) ~ 1,
    (x < 140 & x > 125) & (y < 70 & y > 50) ~ 2,
    (x < 130 & x > 110) & (y < 130 & y > 110) ~ 3,
    (x < 90 & x > 70) & (y < 120 & y > 100) ~ 4,
    (x < 40 & x > 20) & (y < 130 & y > 110) ~ 5,
    (x < 50 & x > 30) & (y < 90 & y > 70) ~ 6,
    (x < 130 & x > 110) & (y < 40 & y > 20) ~ 7
  ))

# extract independent discoveries
independent_finds <- fruits_agent %>%
  filter(movement_mode == 'random') %>%
  select(sim_seed, re, iteration, tree_id, Model)

all_finds <- fruits_agent %>%
  select(sim_seed, re, iteration, tree_id, Model)

# ---- 2. Transition Matrix ----
## based on all sequence
# Extract the trajectory
agent_traj <- fruits_agent %>%
  select(x, y, iteration, sim_seed, re, tree_id, movement_mode, Model) %>%
  arrange(re, sim_seed, iteration)

# Add the start point
agent_start_points <- agent_traj %>%
  group_by(re, sim_seed, Model) %>%
  slice(1) %>%
  ungroup() %>%
  mutate(
    x = 75,
    y = 25,
    iteration = 0,
    tree_id = 0,
    movement_mode = NA
  )

player_finds_matrix <- bind_rows(agent_start_points, agent_traj) %>%
  select(x, y, iteration, sim_seed, re, tree_id, movement_mode, Model) %>%
  arrange(re, sim_seed, iteration) %>%
  group_by(re, sim_seed, Model) %>%
  mutate(
    tree_id_next = lead(tree_id),
    x_next = lead(x),
    y_next = lead(y),
    is_guided_next = lead(movement_mode == 'avatar')
  )

all_finds <- player_finds_matrix %>%
  filter(!is_guided_next) %>%
  rename(exp = sim_seed, time = iteration, name = re) %>%
  filter(exp < 11) %>%
  select(exp, name, time, tree_id, Model)

if(nrow(all_finds) < 2) {
  print("Insufficient data to calculate transfer probability")
} else {
  # create state transition pairs for each participants
  transitions <- all_finds %>%
    arrange(Model, name, exp, time) %>%
    group_by(exp, name, Model) %>%
    mutate(next_tree_id = lead(tree_id)) %>% # get next state
    filter(!is.na(next_tree_id)) %>%
    ungroup()
  
  if(nrow(transitions) == 0) {
    print("the number of state transition pairs is not enough")
  } else {
    # calculate the frequency of each transition
    transition_counts <- transitions %>%
      group_by(Model) %>%
      count(tree_id, next_tree_id, name = "count")
    
    # calculate the total frequency of all transition
    current_state_totals <- transition_counts %>%
      group_by(tree_id, Model) %>%
      summarise(total_from_current = sum(count), .groups = 'drop')
    
    # calculate P(next_tree | tree_id)
    transition_probabilities <- transition_counts %>%
      left_join(current_state_totals, by = c("tree_id", "Model")) %>%
      mutate(probability = count / total_from_current) %>%
      select(tree_id, next_tree_id, probability, Model)
    
    # visualization：
    all_trees <- unique(c(independent_finds$tree_id)) # 所有出现过的树ID
    
    # create transition matrix
    transition_probabilities$tree_id <- as.numeric(transition_probabilities$tree_id)
    transition_probabilities$next_tree_id <- as.numeric(atransition_probabilities$next_tree_id)
    agent_tp_matrix_wide <- transition_probabilities %>%
      filter(Model == 'AN') %>% # select the model you want
      group_by(Model, tree_id, next_tree_id) %>% 
      mutate(probability = mean(probability)) %>%
      ungroup() %>%
      select(-Model) %>%
      distinct() %>%
      pivot_wider(names_from = next_tree_id, values_from = probability, values_fill = 0) %>%
      complete(tree_id = all_trees, fill = list(values_fill = 0)) %>%
      pivot_longer(cols = -tree_id, names_to = "next_tree_id", values_to = "probability") %>%
      filter(tree_id %in% all_trees, next_tree_id %in% all_trees) %>%
      pivot_wider(names_from = next_tree_id, values_from = probability, values_fill = 0)
    
    # visualization for all model
    transition_probabilities$tree_id.f <- factor(transition_probabilities$tree_id, 
                                              levels = c(0,1,6,5,4,3,2,7))
    transition_probabilities$next_tree_id.f <- factor(transition_probabilities$next_tree_id,
                                                  levels = c(0,1,6,5,4,3,2,7))
    if(nrow(transition_probabilities) > 0) {
      ggplot(transition_probabilities, aes(x = tree_id.f, y = next_tree_id.f, fill = probability)) +
        geom_tile() +
        scale_fill_gradient(low = "white", high = "#00BFFF", name = "Transition Prob.") +
        facet_wrap(~ Model, scales = "free_y") +
        labs(title = "Transition Probabilities of Agents (Without Avatar)", x = "Current Tree", y = "Next Tree") +
        theme_minimal() +
        theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 12),
              axis.text.y = element_text(size = 12),
              panel.grid = element_line(colour = 'white'))
    }

  }
}

# ---- 3. Calculate the differences between human matrix and agent matrix ----
# Define Jensen-Shannon Divergence function
js_divergence <- function(p, q, eps = 1e-10) {
  # Add epsilon to avoid log(0)
  p <- p + eps
  q <- q + eps
  m <- 0.5 * (p + q)
  0.5 * sum(p * log(p / m)) + 0.5 * sum(q * log(q / m))
}

# Suppose you have two matrices in this format: mat_A and mat_B
# Example: read from CSVs or create manually
mat_A <- human_tp_matrix_wide

mat_B <- agent_tp_matrix_wide

# Normalize rows to ensure they're probability distributions
normalize_rows <- function(mat) {
  mat_probs <- mat %>% select(-tree_id)
  mat_probs <- t(apply(mat_probs, 1, function(x) x / sum(x)))
  data.frame(tree_id = mat$tree_id, mat_probs)
}

mat_A_norm <- normalize_rows(mat_A)
mat_B_norm <- normalize_rows(mat_B)

# Ensure both matrices have the same `tree_id`s and order
common_ids <- intersect(mat_A_norm$tree_id, mat_B_norm$tree_id)
mat_A_norm <- mat_A_norm %>% filter(tree_id %in% common_ids) %>% arrange(tree_id)
mat_B_norm <- mat_B_norm %>% filter(tree_id %in% common_ids) %>% arrange(tree_id)

# Compute JSD for each matching row
prob_A <- mat_A_norm %>% select(-tree_id)
prob_B <- mat_B_norm %>% select(-tree_id)

js_results_PN <- data.frame(
  tree_id = mat_A_norm$tree_id,
  JSD = mapply(js_divergence, split(prob_A, 1:nrow(prob_A)), split(prob_B, 1:nrow(prob_B)))
)
js_results_PU$model <- "PU"
js_results_PN$model <- "PN"
js_results_AU$model <- "AU"
js_results_AN$model <- "AN"

js_results <- rbind(js_results_PU, js_results_AU, js_results_PN, js_results_AN)

# ---- Visualization ----
js_results %>%
  ggbarplot(x = 'tree_id', y = 'JSD',
            fill = 'model', position = position_dodge(0.9)) +
  scale_fill_manual(name = 'Model', values = c('#87CEFA', '#1874CD', "#40E0D0", "#00868B")) +
  labs(title = "JS Divergence Between Transition Matrices",
       x = "Tree ID",
       y = "Jensen–Shannon Divergence") +
  theme_minimal()

js_results %>%
  arrange(model) %>%
  ggbarplot(x = 'model', y = 'JSD', add = 'mean_se',
            fill = 'model', position = position_dodge(0.9)) +
  scale_fill_manual(name = 'Model', values = c('#87CEFA', '#1874CD', "#40E0D0","#00868B")) +
  labs(title = "JS Divergence Between Transition Matrices",
       x = "Model",
       y = "Jensen–Shannon Divergence") +
  theme_minimal()

# --- Define KL divergence function ---
kl_divergence <- function(p, q, eps = 1e-10) {
  # Add epsilon to avoid log(0)
  p <- p + eps
  q <- q + eps
  sum(p * log(p / q))
}

mat_P <- human_tp_matrix_wide

mat_Q <- agent_tp_matrix_wide

# ---- Normalize ----
mat_P_norm <- normalize_rows(mat_P)
mat_Q_norm <- normalize_rows(mat_Q)

# ---- Ensure same tree_ids and order ----
common_ids <- intersect(mat_P_norm$tree_id, mat_Q_norm$tree_id)
mat_P_norm <- mat_P_norm %>% filter(tree_id %in% common_ids) %>% arrange(tree_id)
mat_Q_norm <- mat_Q_norm %>% filter(tree_id %in% common_ids) %>% arrange(tree_id)

# ---- Compute KL divergence row-wise ----
prob_P <- mat_P_norm %>% select(-tree_id)
prob_Q <- mat_Q_norm %>% select(-tree_id)

kl_results_AN <- data.frame(
  tree_id = mat_P_norm$tree_id,
  KL = mapply(kl_divergence, split(prob_P, 1:nrow(prob_P)), split(prob_Q, 1:nrow(prob_Q)))
)

kl_results_PU$model <- "PU"
kl_results_PN$model <- "PN"
kl_results_AU$model <- "AU"
kl_results_AN$model <- "AN"

kl_results <- rbind(kl_results_PU, kl_results_AU, kl_results_PN, kl_results_AN)

# ---- Visualization ----
kl_results %>%
  ggbarplot(x = 'tree_id', y = 'KL', add = 'mean_se',
            fill = 'model', position = position_dodge(0.9)) +
  scale_fill_manual(name = 'Model', values = c('#87CEFA', '#1874CD', "#40E0D0", "#2F4F4F")) +
  labs(title = "KL Divergence Between Transition Matrices",
       x = "Tree ID (State)",
       y = "Jensen–Shannon Divergence") +
  theme_minimal()

# --- 4. Sequence Edit Distances ---

# extract the independent fruits found for all participants
independent_finds <- player_finds_matrix %>%
  filter(!is_guided_next) %>%
  rename(exp = sim_seed, time = iteration, name = re) %>%
  select(exp, name, time, tree_id, Model)

# rearrange dataframe for distance calculation
independent_sequences_for_distance <- independent_finds %>%
  group_by(exp, name, Model) %>%
  summarise(
    tree_sequence_list = list(tree_id),
    tree_sequence_str = paste(tree_id, collapse = ","),
    .groups = 'drop'
  )

# record the sequence of agent
agent_sequences <- independent_sequences_for_distance
#%>% filter(source == "human")
#agent_sequences <- sequences_for_distance %>% filter(source == "agent")

if(nrow(agent_sequences) > 0) {
  
  # rearrange the data with the order of game sessuibs
  agent_sequences <- agent_sequences %>%
    arrange(Model, name, exp)
  
  # calculate the distances between participants
  seq_pairs_agent <- agent_sequences %>%
    group_by(name, Model) %>%
    arrange(name, Model, exp) %>%
    filter(exp < 11) %>%
    mutate(
      next_sequence = lead(tree_sequence_str),
      next_exp = lead(exp)
    ) %>%
    filter(!is.na(next_sequence)) %>%
    mutate(
      distance = stringdist(tree_sequence_str, next_sequence, method = "lv"),
      pair_label = paste0("Exp_", exp, "_vs_", next_exp)
    )
  
    seq_pairs_agent$exp <- as.factor(seq_pairs_agent$exp)
    #seq_pairs_chimp$exp <- as.numeric(seq_pairs$exp)
    seq_pairs_agent$next_exp <- as.factor(seq_pairs_agent$next_exp)
    #seq_pairs_chimp$next_exp <- as.numeric(seq_pairs$next_exp)
    seq_pairs_agent %>%
    ggline(x = 'next_exp', y = 'distance',
           add = 'mean_sd', facet = 'Model', color = 'Model') +
      scale_fill_manual(values = c('#87CEFA', '#1874CD', "#40E0D0", "#00868B", "#00B2EE")) +
      scale_color_manual(values = c('#87CEFA', '#1874CD', "#40E0D0", "#00868B", "#00B2EE")) +
    labs(title = "Distribution of Sequence Edit Distances (Human)",
         x = "Gameplay Session", y = "Levenshtein Distance") +
    theme_minimal()
  
}