Repository Contents

This repository contains empirical data from human participants, collected for comparison with outputs from an agent-based model (ABM) of primate foraging decision-making.

1. Following_trail_total

Contains trial-level records of follow–explore dynamics for each participant.

time – Timestamp for the current record (in seconds).

total_time – Total number of recorded time steps in the game session for the individual.

exp – Game session identifier.

name – Participant identifier.

x_npc, y_npc – X and Y coordinates of the non-player avatar.

x_player, y_player – X and Y coordinates of the participant.

trial – Target fruit index within the session (1 = first fruit searched for, 2 = second fruit, etc.).

Group – Participant group identifier.

follow_prop – Proportion of time within the trial that the participant followed the avatar.

2. fruit_time_total

Records the time each participant required to find a specified number of fruits per game session.

Time_find – Duration (in seconds) to locate a given number of fruits.

fruit_number – Number of fruits found during the interval.

Other columns follow the same definitions as in Following_trail_total.

3. fruits_visit_all

Summarizes fruit collection counts per participant per session.

visit_number – Total number of fruits found during the session.

Other columns follow the same definitions as in Following_trail_total.

4. human_tp_matrix_wide

Transition matrices for Dutch participants, representing probabilities of moving between spatial locations or states during foraging.

5. seq_pairs_real

Contains sequences of independently located fruit trees and the distances between sequential search patterns across game sessions.

tree_sequence – Fruit tree visit order within a game session.

next_sequence – Visit order in the subsequent game session.

next_exp – Identifier of the subsequent game session.

distance – Sequence edit distance between tree_sequence and next_sequence.

pair_label – Pair identifier linking the current and subsequent game sessions.

Other columns follow the same definitions as in Following_trail_total.
