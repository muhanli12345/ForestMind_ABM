Repository Contents:

This repository contains all scripts and files recording the development of ABM for foraging decison making of primates.

01_ABM_movement_rules:
An R script for running ABM simulations, still under developing and editing.

02_Function_ABM:
This script contains the functions used in the ABM for simulating the movement and behaviour of agents and the avatar.

